import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './components/admin/admin.component';
// import { EditRegistrationComponent } from './components/edit-registration/edit-registration.component';
import { HomeComponent } from './components/home/home.component';
import { ViewRegistrationComponent } from './components/view-registration/view-registration.component';

//defines the routes for your application in this array
const routes: Routes = [

  {
    path: 'add', component: HomeComponent
  },
  {
    path: '', component: AdminComponent
  },
  {
    path: 'view/:id', component : ViewRegistrationComponent
  },
  {
    path: 'edit/:id', component: HomeComponent
  },
  // otherwise redirect to home
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
