import { Injectable } from '@angular/core';

//It allows to make http calls to backend.
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { FormGroup } from '@angular/forms';
import { Bike } from '../components/Bike';

const httpOptions = {
  headers: new HttpHeaders({'Content-Type':'application/json'})
}

@Injectable({
  providedIn: 'root'
})
export class BikeService {

  constructor(private http:HttpClient) { }

  getBikes(){
    return this.http.get<Bike[]>('http://localhost:14080/api/v1/bikes');
  }

  getById(id:string){
    return this.http.get<Bike>('http://localhost:14080/api/v1/bikes/'+id);
  }

  createBikeRegistration(requestBody:any){
    let body = JSON.stringify(requestBody);
    console.log("Submit Add Body : "+body);
    return this.http.post('http://localhost:14080/api/v1/bikes',body,httpOptions);
  }

  updateBikeRegistration(id:string,requestBody:any){
    let body = JSON.stringify(requestBody);
    console.log("Submit Edit Body : "+body);
    return this.http.post('http://localhost:14080/api/v1/bikes/update/'+id,body,httpOptions);
  }
}
