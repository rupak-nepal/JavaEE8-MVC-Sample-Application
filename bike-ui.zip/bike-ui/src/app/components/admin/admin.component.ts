import { Component, OnInit } from '@angular/core';
import { BikeService } from 'src/app/services/bike.service';
import { Bike } from '../Bike';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  //look into this part later
  bikes!: Bike[];

  constructor(private bikeSevice : BikeService) { }

  ngOnInit() {
    this.getBikes();
  }

  getBikes(){
    //getBikes() -> returns an observable and we subsribe to that
    // we will get the data or we get the error back.

    // this method will not be called unless we told the component to call it.
    this.bikeSevice.getBikes().subscribe(
      data => {this.bikes = data},
      err => console.error(err),
      () => console.log('bikes loaded')
    );
  }

}
