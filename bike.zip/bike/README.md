# BikeUi

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 12.2.3.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via a platform of your choice. To use this command, you need to first add a package that implements end-to-end testing capabilities.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.

## TO embed the angular app insdie spring app
https://medium.com/@majdasab/integrating-an-angular-project-with-spring-boot-e3a043b7307b

Or https://dev.to/jakmar17/deploying-angular-application-inside-spring-boot-57g7

or https://www.npmjs.com/package/@ng-bootstrap/ng-bootstrap

//prferred 
or https://www.c-sharpcorner.com/article/add-bootstrap-5-in-angular-11/

## to help styling:

//way to install bootstrap
https://ng-bootstrap.github.io/#/getting-started

https://loiane.com/2017/08/how-to-add-bootstrap-to-an-angular-cli-project/#2-installing-bootstrap-from-npm

npm install bootstrap@4.0.0-beta.2 --save
npm install bootstrap@next  // latest version
<!--  or can try : -> ng add @ng-bootstrap/ng-bootstrap  -->

//it helps with working with Bootstrap nice
https://www.npmjs.com/package/@angular-devkit/core
npm install @angular-devkit/core --save   
or npm i @angular-devkit/core