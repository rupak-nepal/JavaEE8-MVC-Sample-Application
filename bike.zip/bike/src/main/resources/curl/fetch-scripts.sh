#curl --head http://localhost:8081/api/menus
curl -v http://localhost:14080/api/v1/bikes

