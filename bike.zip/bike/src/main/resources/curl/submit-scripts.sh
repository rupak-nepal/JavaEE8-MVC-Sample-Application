curl -d "@json/bike.json" -H "Content-Type: application/json" -X POST http://localhost:14080/api/v1/bikes
#OR
#curl -d '{"id":9,"name":"baeldung"}' -H 'Content-Type: application/json'

