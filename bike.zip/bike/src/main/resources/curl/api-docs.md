####Get List of Menus 
Request:
````
URL: http://localhost:8081/api/menus
Method: Get
````
Response:
``````
> GET /api/menus HTTP/1.1
> Host: localhost:8081
> User-Agent: curl/7.68.0
> Accept: */*
> 
* Mark bundle as not supporting multiuse
< HTTP/1.1 200 
< Content-Type: application/json
< Transfer-Encoding: chunked
< Date: Sat, 24 Jul 2021 13:13:56 GMT
< 

{
  "code" : "0",
  "message" : "Menus Retrieved Successfully.",
  "data" : [ {
    "id" : "1",
    "name" : "Mushroom Soup",
    "unitPrice" : 140.0,
    "quantity" : 0
  }, {
    "id" : "2",
    "name" : "Chicken Momo",
    "unitPrice" : 160.0,
    "quantity" : 0
  }, {
    "id" : "3",
    "name" : "Green Tea",
    "unitPrice" : 120.0,
    "quantity" : 0
  } ]
}
``````
####Get List of Orders 
Request:
````
URL: http://localhost:8081/api/orders
Method: Get
````
Response:
``````
> GET /api/orders HTTP/1.1
> Host: localhost:8081
> User-Agent: curl/7.68.0
> Accept: */*
> 
* Mark bundle as not supporting multiuse
< HTTP/1.1 200 
< Content-Type: application/json
< Transfer-Encoding: chunked
< Date: Sat, 24 Jul 2021 16:24:06 GMT
< 

{
  "code" : "0",
  "message" : "Orders Retrieved Successfully.",
  "data" : [ {
    "id" : 2,
    "orderedItems" : [ {
      "id" : "1",
      "name" : "Mushroom Soup",
      "unitPrice" : 140.0,
      "quantity" : 1
    }, {
      "id" : "2",
      "name" : "Chicken Momo",
      "unitPrice" : 160.0,
      "quantity" : 1
    }, {
      "id" : "3",
      "name" : "Green Tea",
      "unitPrice" : 120.0,
      "quantity" : 1
    } ],
    "orderedDate" : "Sat Jul 24 19:51:13 NPT 2021",
    "amount" : 750.0
  }, {
    "id" : 3,
    "orderedItems" : [ {
      "id" : "1",
      "name" : "Mushroom Soup",
      "unitPrice" : 140.0,
      "quantity" : 1
    }, {
      "id" : "2",
      "name" : "Chicken Momo",
      "unitPrice" : 160.0,
      "quantity" : 1
    }, {
      "id" : "3",
      "name" : "Green Tea",
      "unitPrice" : 120.0,
      "quantity" : 1
    } ],
    "orderedDate" : "Sat Jul 24 19:53:32 NPT 2021",
    "amount" : 750.0
  }, {
    "id" : 4,
    "orderedItems" : [ {
      "id" : "1",
      "name" : "Mushroom Soup",
      "unitPrice" : 140.0,
      "quantity" : 1
    }, {
      "id" : "2",
      "name" : "Chicken Momo",
      "unitPrice" : 160.0,
      "quantity" : 1
    }, {
      "id" : "3",
      "name" : "Green Tea",
      "unitPrice" : 120.0,
      "quantity" : 1
    } ],
    "orderedDate" : "Sat Jul 24 19:54:05 NPT 2021",
    "amount" : 750.0
  } ]

``````
