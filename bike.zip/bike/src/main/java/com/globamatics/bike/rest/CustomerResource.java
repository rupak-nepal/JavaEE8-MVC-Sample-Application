package com.globamatics.bike.rest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

import com.globamatics.bike.models.Bike;
import com.globamatics.bike.models.Customer;
import com.globamatics.bike.models.Hero;
import com.globamatics.bike.models.Message;
import com.globamatics.bike.repositories.BikeRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/customers")
public class CustomerResource {

	private static final Logger LOGGER = Logger.getLogger(CustomerResource.class.getName());

	@Autowired
	private BikeRepository bikeRepository;

	@GetMapping(path = "retrieveinfos")
	public Message getCustomerList() {
		LOGGER.info("Get List");
		return new Message("Success","",Arrays.asList(new Customer(1,"Rpak","H",10,"H"),new Customer(1,"Aus","B",20,"B")));
	}
	
	@PostMapping(path = "create")
	@ResponseStatus(HttpStatus.OK)
	public void registerBike(@RequestBody Customer bike) {
//		if (bikeRepository.findByEmail(bike.getEmail()) != null) {
//			LOGGER.info("Old Bike Found with same email . ");
//		} else {
			LOGGER.info("Registered New Bike "+bike.toString());
//			bikeRepository.save(bike);
//		}
	}

	@GetMapping(path="/{id}")
	@ResponseStatus(HttpStatus.OK)
	public Customer registerBike(@PathVariable("id") long id) {
		return new Customer(3,"NewRupak","H",10,"H");//bikeRepository.getById(id);
	}
	
	@PostMapping(path = "/updatebyid/{id}")
    public void updateBikeRegistration(@PathVariable(value = "id") Long id, @RequestBody Customer bike) {
//		Optional<Bike> retrievedBike = bikeRepository.findById(id);
//		if(retrievedBike.isPresent()) {
//			Bike newBike = retrievedBike.get();
//			newBike.setName(bike.getName());
//			newBike.setPhone(bike.getPhone());
//			newBike.setSerialNumber(bike.getSerialNumber());
//			newBike.setPurchasePrice(bike.getPurchasePrice());
//			bikeRepository.save(newBike);
//		}else {
			LOGGER.info("Updating Customer failed : id not found "+bike.toString());
//		}
    }
}
