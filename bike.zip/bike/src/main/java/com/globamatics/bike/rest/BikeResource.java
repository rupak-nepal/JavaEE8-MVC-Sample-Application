package com.globamatics.bike.rest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

import com.globamatics.bike.models.Bike;
import com.globamatics.bike.models.Hero;
import com.globamatics.bike.repositories.BikeRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/bikes")
public class BikeResource {

	private static final Logger LOGGER = Logger.getLogger(BikeResource.class.getName());

	@Autowired
	private BikeRepository bikeRepository;

	@GetMapping
	public List<Bike> getList() {
		LOGGER.info("Get List");
		return bikeRepository.findAll();
	}
	
	@PostMapping
	@ResponseStatus(HttpStatus.OK)
	public void registerBike(@RequestBody Bike bike) {
		if (bikeRepository.findByEmail(bike.getEmail()) != null) {
			LOGGER.info("Old Bike Found with same email . ");
		} else {
			LOGGER.info("Registered New Bike "+bike.toString());
			bikeRepository.save(bike);
		}
	}

	@GetMapping("/{id}")
	@ResponseStatus(HttpStatus.OK)
	public Bike registerBike(@PathVariable("id") long id) {
		return bikeRepository.getById(id);
	}
	
	@PostMapping("/update/{id}")
    public void updateBikeRegistration(@PathVariable(value = "id") Long id, @RequestBody Bike bike) {
		Optional<Bike> retrievedBike = bikeRepository.findById(id);
		if(retrievedBike.isPresent()) {
			Bike newBike = retrievedBike.get();
			newBike.setName(bike.getName());
			newBike.setEmail(bike.getEmail());
			newBike.setPhone(bike.getPhone());
			newBike.setModel(bike.getModel());
			newBike.setSerialNumber(bike.getSerialNumber());
			newBike.setPurchasePrice(bike.getPurchasePrice());
			bikeRepository.save(newBike);
		}else {
			LOGGER.info("Updating Registered Bike failed : id not found ");
		}
    }
}
