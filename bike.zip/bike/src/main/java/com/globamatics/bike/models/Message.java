package com.globamatics.bike.models;

import java.util.List;

public class Message {

	private String message;
	private String error;
	private List<Customer> customers;
	
	
	public Message(String message, String error, List<Customer> customers) {
		this.message = message;
		this.error = error;
		this.customers = customers;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public List<Customer> getCustomers() {
		return customers;
	}
	public void setCustomers(List<Customer> customers) {
		this.customers = customers;
	}
	
	
}
