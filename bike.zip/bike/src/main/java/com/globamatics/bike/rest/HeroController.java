package com.globamatics.bike.rest;

import java.util.Arrays;
import java.util.List;
import java.util.logging.Logger;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.globamatics.bike.models.Hero;

@RestController
@RequestMapping("/api/v1/heros")
public class HeroController {
	
	private static final Logger LOGGER = Logger.getLogger(HeroController.class.getName());

	@GetMapping
	public List<Hero> getHeroList() {
		
		LOGGER.info("Get List");
		return Arrays.asList(new Hero(1,"Rpak"),new Hero(2, "Asmita"));
	}
}
