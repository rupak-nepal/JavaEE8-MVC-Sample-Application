import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { BikeService } from 'src/app/services/bike.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  form!: FormGroup;
  id!: string;
  isAddMode!: boolean;
  validMessage: string = "";
  submitted = false;

  constructor(
    private formBuilder: FormBuilder,
    private bikeService: BikeService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params.id;
    this.isAddMode = !this.id;
    this.form = this.formBuilder.group({
      name: ['', Validators.required],
      email: ['', Validators.required],
      phone: ['', Validators.required],
      model: ['', Validators.required],
      serialNumber: ['', Validators.required],
      purchasePrice: ['', Validators.required],
      purchaseDate: ['', Validators.required]
    });

    if (!this.isAddMode) {
      this.bikeService.getById(this.id)
        .pipe()
        .subscribe(x => this.form.patchValue(x));
    }
  }
  // convenience getter for easy access to form fields
  get f() { return this.form.controls; }

  onSubmit() {
    this.submitted = true;
    if (this.form.invalid) {
      this.validMessage = "Please fill out the form before submitting.!";
      return;
    }
    if (this.isAddMode) {
      this.validMessage = "Your bike registration has been submitted. Thank you.!";
      this.createBikeRegistration();
    } else {
      this.updateBikeRegistration();
    }
    // if (this.bikeForm.valid) {
    //   this.validMessage = "Your bike registration has been submitted. Thank you.!";
    //   this.bikeService.createBikeRegistration(this.bikeForm.value).subscribe(
    //     data => {
    //       this.bikeForm.reset();
    //       return true;
    //     },
    //     error => {
    //       return Observable.throw(error);
    //     }
    //   )
    // } else {
    //   this.validMessage = "Please fill out the form before submitting.!";
    // }
  }


  private createBikeRegistration() {
    this.bikeService.createBikeRegistration(this.form.value)
      .pipe()
      .subscribe(() => {
        // this.alertService.success('User added', { keepAfterRouteChange: true });
        this.router.navigate(['../'], { relativeTo: this.route });
      });
    // .add(() => this.loading = false);
  }

  private updateBikeRegistration() {
    this.bikeService.updateBikeRegistration(this.id, this.form.value)
      .pipe()
      .subscribe(() => {
        // this.alertService.success('User updated', { keepAfterRouteChange: true });
        this.router.navigate(['../../'], { relativeTo: this.route });
      });
    // .add(() => this.loading = false);
  }

}


