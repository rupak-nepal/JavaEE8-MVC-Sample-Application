import { Component, OnInit } from '@angular/core';
import { BikeService } from 'src/app/services/bike.service';
import { ActivatedRoute } from '@angular/router';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-view-registration',
  templateUrl: './view-registration.component.html',
  styleUrls: ['./view-registration.component.css']
})
export class ViewRegistrationComponent implements OnInit {

  bikeReg!: FormGroup;

  constructor(private bikeService: BikeService, private route : ActivatedRoute) { }

  //how do we get the id off of the route so that we can pass it into the 
  // getBikeReg function that we just created.
  // angular router makes that easy by providing an activated route object.
  ngOnInit(): void {
    this.getBikeReg(this.route.snapshot.params.id);
  }

  getBikeReg(id: string) {
    // this.bikeService.getById(id).subscribe(
    //   data => {
    //     this.bikeReg = data;
    //   },
    //   err => console.error(err),
    //   () => console.log('bikes loaded')
    // );
  }

}
